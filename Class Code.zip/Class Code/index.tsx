import { Box, Heading, Text } from "@chakra-ui/react";
import Navbar from "../components/Navbar";

export default function Home() {
  return (
    <Box>
      <Navbar />

      <Box p={6}>
        <Heading>Welcome to Home Page</Heading>
        <Text mt={2}>This is a simple home page.</Text>
      </Box>
    </Box>
  );
}
